<?php /* Template Name: Coming Soon Template */ ?>
<?php get_header(); ?>
  <div class="body">
  <div class="left-container">
  </div>
  <div class="right-container"> 
  </div>
    <div class="container">
      <img src="<?php echo get_template_directory_uri(); ?>/images/coming-soon.jpg" alt="Coming Soon">
    </div>
  </div>
<?php get_footer(); ?>