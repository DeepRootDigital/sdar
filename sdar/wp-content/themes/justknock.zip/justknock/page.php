<?php get_header(); ?>
      <div class="body">
  <div class="left-container">
  </div>
  <div class="right-container"> 
  </div>
  <!-- <?php include 'fake-sidebars.php'; ?> -->
        <div class="container">
          <div class="row">
              <?php the_content(); ?>
          </div>
        </div>
      </div>
    </div>
<?php get_footer(); ?>