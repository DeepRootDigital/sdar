core-media-query
================

See the [component page](http://polymer.github.io/core-media-query) for more information.