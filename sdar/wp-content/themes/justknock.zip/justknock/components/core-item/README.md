core-item
=========

See the [component page](http://polymer.github.io/core-item) for more information.
