core-menu
=========

See the [component page](http://polymer.github.io/core-menu) for more information.