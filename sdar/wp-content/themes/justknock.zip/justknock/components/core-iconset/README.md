core-iconset
============

See the [component page](http://polymer.github.io/core-iconset) for more information.
