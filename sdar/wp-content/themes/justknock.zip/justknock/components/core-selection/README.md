core-selection
==============

See the [component page](http://polymer.github.io/core-selection) for more information.